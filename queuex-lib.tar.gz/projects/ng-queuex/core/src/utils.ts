declare const ngDevMode: boolean | undefined;

export const NG_DEV_MODE = typeof ngDevMode === 'undefined' || !!ngDevMode;
